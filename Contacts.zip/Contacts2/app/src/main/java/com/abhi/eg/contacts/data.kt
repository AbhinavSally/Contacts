package com.abhi.eg.contacts

import android.graphics.Bitmap

public data class data (var email : String , var password : String)