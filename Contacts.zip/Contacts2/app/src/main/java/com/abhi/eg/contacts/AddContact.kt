package com.abhi.eg.contacts

import android.app.Activity.RESULT_CANCELED
import android.app.Activity.RESULT_OK
import android.app.AlertDialog
import android.content.DialogInterface
import android.content.Intent
import android.database.Cursor
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.navigation.findNavController
import kotlinx.android.synthetic.main.fragment_add_contact.*
import kotlinx.coroutines.launch


class AddContact : BaseFragment() {

lateinit var addImage:String
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_add_contact, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        facADD.setOnClickListener {
        selectImage()

        }

    }
    private fun selectImage() {
        val options =
            arrayOf<CharSequence>("Take Photo", "Choose from Gallery", "Cancel")
        val builder: AlertDialog.Builder = AlertDialog.Builder(context)
        builder.setTitle("Choose your profile picture")
        builder.setItems(options, DialogInterface.OnClickListener { dialog, item ->
            if (options[item] == "Take Photo") {
                val takePicture =
                    Intent(MediaStore.ACTION_IMAGE_CAPTURE)
                startActivityForResult(takePicture, 0)
            } else if (options[item] == "Choose from Gallery") {
                val pickPhoto = Intent(
                    Intent.ACTION_PICK,
                    MediaStore.Images.Media.EXTERNAL_CONTENT_URI
                )
                startActivityForResult(pickPhoto, 1)
            } else if (options[item] == "Cancel") {
                dialog.dismiss()
            }
        })
        builder.show()
    }
    override fun onActivityResult(
        requestCode: Int,
        resultCode: Int,
        data: Intent?
    ) {
        if (resultCode != RESULT_CANCELED) {
            when (requestCode) {
                0 -> if (resultCode == RESULT_OK && data != null) {
                    val selectedImage = data.extras!!["data"] as Bitmap?
                    ivProfileAdd.setImageBitmap(selectedImage)
                }
                1 -> if (resultCode == RESULT_OK && data != null) {
                    val selectedImage: Uri? = data.data
                    val filePathColumn =
                        arrayOf(MediaStore.Images.Media.DATA)
                    if (selectedImage != null) {
                        val cursor: Cursor? = activity?.applicationContext?.getContentResolver()
                            ?.query(
                                selectedImage,
                                filePathColumn, null, null, null
                            )
                        if (cursor != null) {
                            cursor.moveToFirst()
                            val columnIndex: Int = cursor.getColumnIndex(filePathColumn[0])
                            val picturePath: String = cursor.getString(columnIndex)
                            ivProfileAdd.setImageBitmap(BitmapFactory.decodeFile(picturePath))
                            addImage=picturePath.toString().trim()

                            cursor.close()
                        }
                    }
                }
            }
        }
    }
    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)

        /*     */


        btnSave.setOnClickListener {
            val addName = etADDNAME.text.toString().trim()
            val addNumber = etADDNUMBER.text.toString().trim()

            if (addName.isEmpty()) {
                etADDNAME.error = "Name Required"
                etADDNAME.requestFocus()
                return@setOnClickListener
            }
            if (addNumber.isEmpty()) {
                etADDNUMBER.error = "Number Required"
                etADDNUMBER.requestFocus()
                return@setOnClickListener
            }

            launch {
                val contact = Contact(addName, addNumber, addImage)
                context?.let {
                    AppDatabase(it).getContactDao().addContact(contact)
                    //it.toast("Contact Saved")
                    //after click save get back to the recycler fragment
                    view!!.findNavController()
                        .navigate(R.id.action_addContact_to_recyclerView)

                }
            }

        }


    }
}

