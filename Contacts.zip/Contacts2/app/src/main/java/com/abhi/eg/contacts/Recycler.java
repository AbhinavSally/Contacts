package com.abhi.eg.contacts;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class Recycler extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recycler);
    }

    @Override
    public void onBackPressed() {
        finish();
    }
}
